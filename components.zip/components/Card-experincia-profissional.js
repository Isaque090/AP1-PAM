import { Text, View, StyleSheet,  } from 'react-native';

import { Card } from '../components/card';
export function CardExperienciaProfissional({ empresa, cargo, periodo, descricao,cor }) {
  return (
    <View style={styles.conteiner}>
    <Card>
          <Text style={[styles.empresa,{ color:cor}]}>{empresa}</Text>

          <Text style={styles.cargo}>{cargo}</Text>

          <Text style={styles.periodo}>{periodo}</Text>

          <Text style={styles.descricao}>
           {descricao}
          </Text>
        </Card>
      </View>
  );
}

const styles = StyleSheet.create({
  conteiner: {
    marginTop: 20,
    alignItems: 'center',
  },empresa: {
    fontSize: 20,
    fontWeight: 'bold',

    marginBottom: 5,
  },

  cargo: {
    fontSize: 16,
    fontWeight: '600',
  },

  periodo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },

  descricao: {
    fontSize: 16,
    width: 320,
  },
 
});
