 import { Text, View, StyleSheet, Image } from 'react-native';

import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Card } from '../components/card';
export function CardDadosPessoais() {
  return (
   <View style={styles.conteiner}>
        <Card>
          <Text style={styles.texto}>Dados Pessoais</Text>
          <View style={styles.linha}>
          <MaterialIcons name="person" size={24} color="#555" style={styles.icon} />
            <Text style={styles.textoGrifado}>Nome:</Text>
            <Text style={styles.dados}>Isaque Severo Ferreira</Text>
          </View>
          <View style={styles.linha}>
          <MaterialIcons name="cake" size={24} color="#555" style={styles.icon} />
            <Text style={styles.textoGrifado}>Data de Nascimento:</Text>
            <Text style={styles.dados}>21/09/2009</Text>
          </View>

          <View style={styles.linha}>
          <MaterialIcons name="location-on" size={24} color="#555" style={styles.icon} />
            <Text style={styles.textoGrifado}>Cidade:</Text>
            <Text style={styles.dados}>Itanhaém - SP</Text>
          </View>

 <View style={styles.linha}>
         <MaterialIcons name="family-restroom" size={24} color="#555" style={styles.icon}  />
            <Text style={styles.textoGrifado}>Estado civil:</Text>
            <Text style={styles.dados}>Solteiro</Text>
          </View>
          <View style={styles.linha}>
  <MaterialIcons name="wc" size={24} color="#555" style={styles.icon} />
  <Text style={styles.textoGrifado}>Sexo:</Text>
  <Text style={styles.dados}>Masculino</Text>
</View>
         
        </Card>
      </View>
  );
}

const styles = StyleSheet.create({

  conteiner: {
    marginTop: 30,
  
  },

  texto: {
    fontSize: 30,

    textAlign: 'center',
  },
  dados: {
    fontSize: 18,
    
  },
  linha: {
    flexDirection: 'row',
    marginTop: 14,
    width: 350,
  },
  textoGrifado: {
    fontWeight: 'bold',
    fontSize: 18,
    marginRight: 5,
    alignItems: 'left',
  },
  icon: {
    marginRight: 10,
    
  },
  
});
