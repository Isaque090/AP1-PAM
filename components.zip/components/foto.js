import { Text, View, StyleSheet, Image } from 'react-native';

export function Foto() {
  return (
    <View style={styles.foto}>
    <Image  style={{ width: 140, height: 140, borderRadius: 90,borderWidth:2, }} source={require('../assets/img/foto-isaque.jpg')}/>
    <Text  style={styles.textoo}>Isaque Severo Ferreira</Text>
      <Text  style={styles.cidade}>Itanhaém - SP</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  foto:{
     marginTop:20,
     alignItems:'center',
   },
   textoo:{fontSize: 23,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 4,
    marginTop:10,},cidade: {
    fontSize: 17,
    color: '#666',
  },
  
});
