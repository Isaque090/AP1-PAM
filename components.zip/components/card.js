import { Text, View, StyleSheet, Image } from 'react-native';

export function Card({texto,children}) {
  return (
    <View style={styles.container}>
      
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
   
    justifyContent: 'center',
  
       backgroundColor:'#fff',
 padding:18,
    color: '#000',
    borderRadius:10,
    shadowColor:'#fff',
    elevation: 5,
   
  },
  
});
