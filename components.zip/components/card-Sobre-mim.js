

import { Text, View, StyleSheet, Image } from 'react-native';

import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Card } from '../components/card';
export function CardSobreMim() {
  return (
   <View style={styles.conteiner}>
        <Card>
          <Text style={styles.texto}>Sobre Mim</Text>
   
          <View style={styles.linha}>

  
  <Text style={styles.dados}>Olá! Eu sou o Isaque e atualmente estou cursando o Técnico em Desenvolvimento de Sistemas integrado ao Ensino Médio. Gosto de aprender tecnologias novas e resolver problemas reais com programação. Atualmente focado em web development (front-end + back-end).</Text>
</View>



         
        </Card>

      </View>
  );
}

const styles = StyleSheet.create({

  conteiner: {
    marginTop: 30,
  
  },

  texto: {
    fontSize: 30,

    textAlign: 'center',
  },
  dados: {
    fontSize: 18,
    
  },
  linha: {
    flexDirection: 'row',
    marginTop: 14,
    width: 350,
  },
  
});
