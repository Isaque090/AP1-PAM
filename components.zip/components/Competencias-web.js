import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Linking,
  Image,
  ScrollView,
} from 'react-native';
import { Card } from '../components/card';

import Fontisto from '@expo/vector-icons/Fontisto';
import Ionicons from '@expo/vector-icons/Ionicons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
export function DesenvolvimentoWeb() {
  return (
    <View style={styles.card}>
      <Card>
        <View style={styles.linha}>
          <Text style={styles.texto}>Desenvolvimento Web</Text>
        </View>
        <View style={styles.linha}>
          <Text style={styles.textoStack}>Front-end</Text>
        </View>

        <View style={[styles.linha, styles.icon]}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            decelerationRate="fast">
            <View style={styles.centralizar}>
              <Fontisto name="html5" size={70} color="orange" />
              <Text style={styles.nomeTec}>HTML5</Text>
              <Text style={styles.nivel}>Intermediário</Text>
            </View>
            <View style={styles.centralizar}>
              <Fontisto name="css3" size={70} color="blue" />
              <Text style={styles.nomeTec}>CSS3</Text>
              <Text style={styles.nivel}>Intermediário</Text>
            </View>
            <View style={styles.centralizar}>
              <Ionicons name="logo-javascript" size={70} color="yellow" />
              <Text style={styles.nomeTec}>Java Script</Text>
              <Text style={styles.nivel}>Básico a Intermediário</Text>
            </View>
            <View style={styles.centralizar}>
              <FontAwesome6 name="bootstrap" size={70} color="purple" />
              <Text style={styles.nomeTec}>Bootstrap</Text>
              <Text style={styles.nivel}>Intermediário</Text>
            </View>
          </ScrollView>
          
        </View>
        

        <View style={styles.linha}></View>

        <View style={styles.linha}>
          <Text style={styles.textoStack}>Back-end</Text>
        </View>
        <View style={[styles.linha, styles.icon]}>
          <View style={styles.centralizar}>
            <Fontisto name="php" size={70} color="#787BB4" />
            <Text style={styles.nomeTecphp}>PHP</Text>
            <Text style={styles.nivel}>Básico a Intermediário</Text>
          </View>
        </View>
        
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    marginTop: 30,
  },

  texto: {
    fontSize: 30,
    alignItems: 'center',
    textAlign: 'center',

    width: '100%',
  },

  linha: {
    flexDirection: 'row',

    width: 350,
  },
  icon: {
    marginTop: 20,
  },
  centralizar: {
    alignItems: 'center',
    marginRight: 40,
    marginLeft: 10,
  },
  textoStack: {
    fontSize: 26,
    alignItems: 'center',
    textAlign: 'center',
    color: 'blue',
    fontWeight: 'bold',
    marginTop: 14,
  },

  nomeTec: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  nomeTecphp: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  nivel: {
    marginTop: 4,
    fontSize: 13,
    fontWeight: '500',
    color: '#666',
    width: 80,
    textAlign: 'center',
  },
});
