import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Linking,
} from 'react-native';

function Abrirsite(url) {
  Linking.canOpenURL(url);

  Linking.openURL(url);
}
export function Projetos() {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.projetoCard}
        onPress={() =>
          Abrirsite('https://snack.expo.dev/@davi_adme0/pam-cardapio-digital')
        }>
        <Text style={styles.nome}>App de Cardapio</Text>
        <Text style={styles.tecnologias}>React Native</Text>
        <Text style={styles.descricao}>
          Aplicativo para exibir cardápio digital com categorias e detalhes dos
          pratos, feito em React Native.
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.projetoCard}
        onPress={() => Abrirsite('https://github.com/Isaque090/quiz-')}>
        <Text style={styles.nome}>Site Quiz</Text>
        <Text style={styles.tecnologias}>
          HTML5 | CSS | Java Script | Bootstrap | PHP | Mysql
        </Text>
        <Text style={styles.descricao}>
          Aplicativo de Quiz interativo com sistema de pontuação e ranking dos
          10 melhores jogadores. Permite que o usuário escolha nome e foto de
          perfil para personalizar a experiência, tornando a competição mais
          divertida e social.
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.projetoCard}
        onPress={() =>
          Abrirsite('https://github.com/Isaque090/atividade-struct-tpa')
        }>
        <Text style={styles.nome}>Projeto Struct</Text>
        <Text style={styles.tecnologias}>C#</Text>
        <Text style={styles.descricao}>
          Projeto demonstrando o uso de structs para organizar e manipular dados
          de forma estruturada, aplicando conceitos de programação como
          encapsulamento de informações, leitura e escrita de dados, e boas
          práticas em organização de código.
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 15,
    width: '90%',
  },

  projetoCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },

  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
    color: '#333',
  },

  tecnologias: {
    fontSize: 14,
    fontWeight: '600',
    color: '#007aff',
    marginBottom: 6,
  },

  descricao: {
    fontSize: 14,
    color: '#555',
    lineHeight: 18,
  },
});
