import { Text, View, StyleSheet, Image } from 'react-native';
import {
  
  TouchableOpacity,
  Linking
} from 'react-native';
import { Card } from '../components/card';

import AntDesign from '@expo/vector-icons/AntDesign';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

function Abrirsite(url) {
  Linking.canOpenURL(url);

  Linking.openURL(url);
}

export function CardContatos() {
  return (
   <View style={styles.card2}>
        <Card>
          <Text style={styles.texto}>Contatos</Text>
          <View style={styles.linha}>
            <AntDesign
              name="github"
              size={20}
              color="black"
              style={styles.icon}
            />
            <Text style={styles.textoGrifado}>Github:</Text>

            <TouchableOpacity
              style={styles.link}
              onPress={() => Abrirsite('https://github.com/Isaque090')}>
              {' '}
              <Text style={styles.dados,styles.link}>https://github.com/Isaque090</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.linha}>
            <FontAwesome
              name="linkedin-square"
              size={20}
              color="black"
              style={styles.icon}
            />
            <Text style={styles.textoGrifado}>Linkedin:</Text>
             <TouchableOpacity
              onPress={() => Abrirsite('https://www.linkedin.com/in/isaque-severo-b37824335/')}>
              {' '}
            <Text style={styles.dados,styles.link}>isaque-severo-b37824335</Text>
             </TouchableOpacity>
          </View>
          <View style={styles.linha}>
            <FontAwesome
              name="phone-square"
              size={20}
              style={styles.icon}
              color="black"
            />
            <Text style={styles.textoGrifado}>Telefone:</Text>
            <TouchableOpacity
              onPress={() => Abrirsite('https://wa.me/5511930691078')}>
              {' '}
              <Text style={styles.dados,styles.link}>(11) 93069-1078</Text>
            </TouchableOpacity>
          </View>

     <View style={styles.linha}>
            <MaterialIcons name="email" size={22} color="black"  style={styles.icon} />
             
             
            <Text style={styles.textoGrifado}>E-mail:</Text>
            <TouchableOpacity
              onPress={() => Abrirsite('mailto:Isaquesevero8305@gmail.com')}>
              {' '}
              <Text style={styles.dados,styles.link}>Isaquesevero8305@gmail.com</Text>
            </TouchableOpacity>
          </View>
          
        </Card>
      </View>
    
  );
}

const styles = StyleSheet.create({
  
  card2: {
    marginTop: 50,
    marginBottom: 10,
  },

  texto: {
    fontSize: 30,

    textAlign: 'center',
  },
  dados: {
    fontSize: 18,
    
  },
  linha: {
    flexDirection: 'row',
    marginTop: 14,
    width: 350,
  },
  textoGrifado: {
    fontWeight: 'bold',
    fontSize: 18,
    marginRight: 5,
    alignItems: 'left',
  },
  icon: {
    marginRight: 10,
    marginTop:3,
  },link:{
    fontSize: 18,
    color: '#007AFF'},
 
  
});
