
import {
  StyleSheet,
  Text,
  View,
 
} from 'react-native';
import { Card } from '../components/card';
import Fontisto from '@expo/vector-icons/Fontisto';
export function BancoDeDados() {
  return (
     <View style={styles.card}>
        <Card>
          <View style={styles.linha}>
            <Text style={styles.texto}>Banco de dados</Text>
          </View>
        
     
          <View style={[styles.linha, styles.icon]}>
        
            <View style={styles.centralizar}>
     <Fontisto name="mysql" size={70} color="#00758f" />
              <Text style={styles.nomeTec}>Mysql</Text>
              <Text style={styles.nivel}>Intermediário</Text>
            </View>
          
            
           
          </View>
               
         
         
        </Card>
      </View>

  );
}

const styles = StyleSheet.create({
 
  card: {
    marginTop: 30,
    
  },

  texto: {
    fontSize: 30,
    alignItems: 'center',
    textAlign: 'center',

    width: '100%',
  },

  linha: {
    flexDirection: 'row',

    width: 350,
  },
  icon: {
    marginTop: 20,
  },
  centralizar: {
    alignItems: 'center',
    marginRight: 40,
    marginLeft: 10,
  },
 

  nomeTec: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  nivel: {
    marginTop: 4,
    fontSize: 13,
    fontWeight: '500',
    color: '#666',
    width:80,
     textAlign: 'center',
  },
  
});
