
import {
  StyleSheet,
  Text,
  View,
 
} from 'react-native';
import { Card } from '../components/card';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

export function DesenvolvimentoMobile() {
  return (
     <View style={styles.card}>
        <Card>
          <View style={styles.linha}>
            <Text style={styles.texto}>Desenvolvimento Mobile</Text>
          </View>
          <View style={styles.linha}>
            <Text style={styles.textoStack}>Front-end</Text>
          </View>
     
          <View style={[styles.linha, styles.icon]}>
        
            <View style={styles.centralizar}>
              <MaterialCommunityIcons name="react" size={62} color="#61DAFB" />
              <Text style={styles.nomeTec}>React Native</Text>
              <Text style={styles.nivel}>Básico</Text>
            </View>
          
            
           
          </View>
               
         
         
        </Card>
      </View>

  );
}

const styles = StyleSheet.create({
 
  card: {
    marginTop: 30,
    
  },

  texto: {
    fontSize: 30,
    alignItems: 'center',
    textAlign: 'center',

    width: '100%',
  },

  linha: {
    flexDirection: 'row',

    width: 350,
  },
  icon: {
    marginTop: 20,
  },
  centralizar: {
    alignItems: 'center',
    marginRight: 40,
    marginLeft: 10,
  },
  textoStack: {
    fontSize: 26,
    alignItems: 'center',
    textAlign: 'center',
    color: 'blue',
    fontWeight: 'bold',
    marginTop: 14,
  
  
  },

  nomeTec: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  nivel: {
    marginTop: 4,
    fontSize: 13,
    fontWeight: '500',
    color: '#666',
    width:80,
     textAlign: 'center',
  },
  
});
