import { Text, View, StyleSheet, Image } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Card } from '../components/card';
export function CardEscola({ escola, imagem, ano, cidade }) {
  return (
    <View style={styles.conteiner}>
    <Card >
      <Text style={styles.escola}>{escola}</Text>

      <Image
        source={imagem}
        style={{
          width: 270,
          height: 145,
          resizeMode: 'cover',
          borderRadius: 10,
          marginLeft:23,
         
        }}
      />
      <View style={styles.linha}>
        <MaterialIcons
          name="school"
          size={24}
          color="#555"
          style={styles.icon}
        />
        <Text style={styles.ano}>{ano}</Text>
      </View>
      <View style={styles.linha}>
        <MaterialIcons name="location-on" size={24} color="#555" />
        <Text style={styles.cidade}>{cidade}</Text>
      </View>
    </Card>
      </View>
  );
}

const styles = StyleSheet.create({
  conteiner:{
    width:350,
    marginTop:30,
  },
  linha: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  escola: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 10,
  },
  ano: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginTop: 12,
    marginBottom: 8,
    marginLeft: 5,
    width:290,
 
  },
  cidade: {
    fontSize: 16,
    color: '#555',
    fontWeight: '500',
    marginLeft: 5,
  },
});
