
import {
  StyleSheet,
  Text,
  ScrollView
  
} from 'react-native';

import { DesenvolvimentoWeb } from '../components/Competencias-web';

import {  DesenvolvimentoMobile } from '../components/Competencias-Mobile';
import {  DesenvolvimentoDesktop } from '../components/Competencias-Desktop';
import {  Projetos } from '../components/projetos';
import {  BancoDeDados } from '../components/Competencias-Banco-dados';

export function Competencias() {
  return (
   <ScrollView

  contentContainerStyle={styles.content}
      style={styles.container}>
      <Text style={styles.titulo}>Competências técnicas</Text>
    <DesenvolvimentoWeb/>
    < DesenvolvimentoMobile/>
    <DesenvolvimentoDesktop/>
    <BancoDeDados/>
    <Text style={styles.titulo}>Meus Projetos</Text>
    <Projetos/>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: 50,
   

  },
  content:{
  paddingBottom: 90,
     alignItems: 'center',
  },

  titulo: {
    fontSize: 34,
    marginTop: 10,
   
  },
  
});
