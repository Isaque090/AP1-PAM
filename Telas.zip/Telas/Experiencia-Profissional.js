import { StyleSheet, View, ScrollView, Text, Image } from 'react-native';
import { CardEscola } from '../components/card-escola';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Card } from '../components/card';

import { CardExperienciaProfissional } from '../components/Card-experincia-profissional';
export function ExperienciaProfissional() {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}> Experiências
Profissionais</Text>
<ScrollView  showsVerticalScrollIndicator={false}

      contentContainerStyle={{ paddingBottom: 40 }}
  >
      <CardExperienciaProfissional
        empresa={'Itaú Unibanco'}
        cargo={'Desenvolvedor Front-End Júnior'}
        periodo={'Jan/2025 - Dez/2025'}
        descricao={
          ' Atuação no desenvolvimento de interfaces web responsivas utilizando HTML, CSS, JavaScript e Bootstrap Responsável pela criação de layouts modernos, implementação de componentes visuais e melhorias na experiência do usuário (UX/UI). Participação na manutenção e atualização de sistemas internos.'
        }
        cor={'#EC7000'}
      />

 <CardExperienciaProfissional
 cor={'#007aff'}
        empresa={'Projetos Pessoais'}
        cargo={'Desenvolvedor Front-End'}
        periodo={'Fev/2025 - Nov/2025'}
        descricao={
          'Desenvolvimento de projetos web utilizando HTML5, CSS, JavaScript e Bootstrap. Criação de interfaces responsivas, páginas interativas e componentes reutilizáveis, com foco em usabilidade e experiência do usuário. . Projetos incluem páginas institucionais, layouts modernos e aplicações simples para prática de desenvolvimento.'
        }
      />

      
 <CardExperienciaProfissional
 cor={'#007aff'}
        empresa={'Projetos Pessoais'}
        cargo={'Desenvolvedor Full-Stack'}
        periodo={'Nov/2025 - 2026'}
        descricao={
          'Desenvolvimento de aplicações web completas, atuando no front-end e back-end. Utilização de HTML, CSS, JavaScript, PHP e Banco de dados. Atuando na Criação de sistemas simples com foco em aprendizado e evolução técnica.'
        }
      />
     
         
        </ScrollView>

     
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: 50,
    alignItems: 'center',
  },
  titulo: {
    fontSize: 29,
  },
  
 
});
