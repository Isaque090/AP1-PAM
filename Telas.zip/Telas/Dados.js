
import {
  StyleSheet,
  View,ScrollView
} from 'react-native';

import { Foto } from '../components/foto';
import { CardDadosPessoais } from '../components/card-dados-pessoais';
import { CardContatos } from '../components/card-Contatos';
import { CardSobreMim } from '../components/card-Sobre-mim';

export function DadosPessoais() {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 90 }}>
  <Foto/>
     <CardDadosPessoais/>
     <CardContatos/>
     <CardSobreMim/>
   </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: 50,
    alignItems: 'center',
  },

  
});
