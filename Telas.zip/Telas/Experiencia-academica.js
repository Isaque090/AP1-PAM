
import {
  StyleSheet,
  View,ScrollView,Text,Image
} from 'react-native';
import { CardEscola } from '../components/card-escola';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

export function ExperienciaAcademicas() {
  return (
    <View  style={styles.container}>
  <Text  style={styles.titulo}>Experiências Acadêmicas</Text>
   <ScrollView
  showsVerticalScrollIndicator={false}

      contentContainerStyle={{ paddingBottom: 90 }}
  
>
<CardEscola escola={'E.E Fulvio Abramo'} imagem={require('../assets/img/escola-fulvioabramo.png')} ano={'1°ano Ao 5°ano | Fundamental I'} cidade={'Cidade:São Paulo-SP'}/>

<CardEscola escola={'Emef Olinda Menezes Serra Vidal'} imagem={require('../assets/img/escola-olinda.jpg')} ano={'6°ano Ao 9°ano | Fundamental II'} cidade={'Cidade:São Paulo-SP'}/>

<CardEscola escola={'Etec Itanhaém'} imagem={require('../assets/img/etec-itanhaem.jpg')} ano={'1°ano Ao 3°ano | Ensino Médio Integrado ao Técnico em Desenvolvimento de Sistemas'} cidade={'Cidade:Itanhaém-SP'}/>
  </ScrollView>


   </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: 50,
    alignItems: 'center',
  },
titulo:{
  fontSize:29,
}
,
});
